/*
	Authors: Jonghyun Yoo and Tristan Sladek
	Date: 9/15/2018
	Program: Data Converter
	Description: Will read in .dat files, convert them to java objects,
	then output a list of the appropriate object.
*/
package files;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import classes.*;

public class DataReader {
	
	//Reads in the customers.dat file and outputs an arraylist of Java Objects
	public static ArrayList<Customer> readCustomers(){
		//Initializing our list
		ArrayList<Customer> customers = new ArrayList<Customer>();		
		//Reading in the file
		try {
			BufferedReader br = new BufferedReader(new FileReader("data//Customers.dat"));
			//numReads is the first line of each .dat file, it contains a number that tells us how many lines there are
			//in the dat file.
			int numReads = Integer.parseInt(br.readLine());
			for(int i = 0; i<numReads;i++) {
				//we read in the line, convert all ';' to ',' , split the line into a string array, then send the entire string array into customers to be constructed.
				String line = br.readLine().replace(';', ',');
				String[] lines = line.split(",");
				customers.add(new Customer(lines));
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//return the arrayList when all processing is done
		return customers;
	}
	
	public static ArrayList<Person> readPeople(){
		//Initializing our list
		ArrayList<Person> people = new ArrayList<Person>();
		//Reading in the file
		try {
			BufferedReader br = new BufferedReader(new FileReader("data//Persons.dat"));
			//numReads is the first line of each .dat file, it contains a number that tells us how many lines there are
			//in the dat file.
			int numReads = Integer.parseInt(br.readLine());
			for(int i = 0; i<numReads;i++) {
				//we read in the line, convert all ';' to ',' , split the line into a string array, then send the entire string array into people to be constructed.
				String line = br.readLine().replace(';', ',');
				String[] lines = line.split(",");
				people.add(new Person(lines));				
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//return the arrayList when all processing is done
		return people;
	}
	
	public static ArrayList<Product> readProducts(){
		//Initializing our list
		ArrayList<Product> products = new ArrayList<Product>();
		//Reading in our file
		try {
			BufferedReader br = new BufferedReader(new FileReader("data//Products.dat"));
			//numReads is the first line of each .dat file, it contains a number that tells us how many lines there are
			//in the dat file.
			int numReads = Integer.parseInt(br.readLine());
			for(int i = 0; i<numReads;i++) {
				//we read in the line, convert all ';' to ',' , split the line into a string array
				String line = br.readLine().replace(';', ',');
				String[] lines = line.split(",");
				
				//Depending on the character code in the second arg, we add a different object
				switch(lines[1]) {
				case "M":
					products.add(new MovieTicket(lines));
					break;
				case "S":
					products.add(new SeasonPass(lines));
					break;
				case "P":
					products.add(new ParkingPass(lines));
					break;
				case "R":
					products.add(new Refreshment(lines));
					break;
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//returning our product list once all processing is done
		return products;
	}
	public static InvoiceList readInvoices(){
		//Initializing our list
		InvoiceList invoices = new InvoiceList();
		ArrayList<Customer> customers = readCustomers();
		ArrayList<Product> products = readProducts();
		ArrayList<Person> people = readPeople();
		
		//Reading in our file
		try {
			BufferedReader br = new BufferedReader(new FileReader("data//Invoices.dat"));
			//numReads is the first line of each .dat file, it contains a number that tells us how many lines there are
			//in the dat file.
			int numReads = Integer.parseInt(br.readLine());
			for(int i = 0; i<numReads;i++) {
				//Lines is every read line
				String[] lines = br.readLine().split(";");
				//The fifth element is the list of products in the invoice
				String[] prodList = lines[4].split(",");
				
				Invoice tempInvoice = new Invoice();
				tempInvoice.setInvoiceCode(lines[0]);
				
				for(Customer c : customers) {
					if(c.getPersonCode().equals(lines[1])) {
						tempInvoice.setCustomer(c);
						break;
					}
				}
				for(Person p: people) {
					if(p.getPersonCode().equals(lines[2])) {
						tempInvoice.setSalesPerson(p);
						break;
					}
				}
				
				try {
					tempInvoice.setInvoiceDate(new SimpleDateFormat("yyyy-MM-dd").parse(lines[3]));	
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				//every product is separated by comma
				for(String product: prodList) {
					//all product info is separated by colon
					String[] prodInfo = product.split(":");
					//products being the product list we read in earlier in the program
					
					Product theProduct = null;
					
					for(Product p:products) {
						//we check to see what type of product we have
						//we'll use this later.
						if(p.getProductCode().equals(prodInfo[0])){
							theProduct = p;
							break;
						}
					}
					
					switch(theProduct.getProductType()) {
					case "M":
						tempInvoice.AddPurchase(new MoviePurchase(Integer.parseInt(prodInfo[1]),theProduct));
						break;
					case "S":
						tempInvoice.AddPurchase(new SeasonPassPurchase(Integer.parseInt(prodInfo[1]),theProduct));
						break;
					case "P":
						//it will be = 3 if we have a ticketcode
						if(prodInfo.length == 3) {
							tempInvoice.AddPurchase(new ParkingPurchase(Integer.parseInt(prodInfo[1]),theProduct,prodInfo[2]));
						}else {
							tempInvoice.AddPurchase(new ParkingPurchase(Integer.parseInt(prodInfo[1]),theProduct));
						}
						break;
					case "R":
						tempInvoice.AddPurchase(new RefreshmentPurchase(Integer.parseInt(prodInfo[1]),theProduct));
						break;
					}
				}
				invoices.add(tempInvoice);				
			}			
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//returning our product list once all processing is done
		return invoices;
	}

}
