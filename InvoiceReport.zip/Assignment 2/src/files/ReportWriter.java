package files;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import classes.Address;
import classes.Invoice;
import classes.InvoiceList;
import classes.MovieTicket;
import classes.ParkingPass;
import classes.ParkingPurchase;
import classes.Person;
import classes.Purchase;
import classes.Refreshment;
import classes.SeasonPass;
import sql.DBReader;

public class ReportWriter {
	
	//Print the Summary Report for the selected invoice list
	public static void PrintSummaryReport(InvoiceList invoiceList) {
		//Headers
		System.out.println("========================");
		System.out.println("Executive Summary Report");
		System.out.println("========================");
		System.out.printf("%-10s%-40s%-20s%12s%12s%12s%12s%12s\n","Invoice","Customer","Salesperson","Subtotal","Fees","Taxes","Discount","Total");
		
		double grandSubtotal = 0;
		double grandFees = 0;
		double grandTaxes = 0;
		double grandDiscount = 0;
		double grandTotal = 0;
		
		for(int i=0;i<invoiceList.getSize();i++) {
			Invoice invoice = invoiceList.getInvoice(i);
			String custType = "[General]";
			double subtotal = 0;
			double fees = 0;
			double taxes = 0;
			double discount = 0;
			double total = 0;
			
			//Grab all values from purchase objects in the invoice's Purchase List
			for(Purchase p: invoice.getPurchaseList()) {
				subtotal+=p.getSubtotal(invoice);
				taxes+=p.getTaxes(invoice);
				total+=p.getTotal(invoice);
			}
			//Check if the customer is a student
			if(invoice.getCustomer().getType().equals("S")) {
				custType = "[Student]";
				fees = 6.75;
				discount = taxes+(subtotal*.08);
				total = total+fees-discount;				
			}
			//Print out the line 
			System.out.printf("%-10s%-40s%-20s $%10.2f $%10.2f $%10.2f $%10.2f $%10.2f\n",
					invoice.getInvoiceCode(),
					invoice.getCustomer().getName()+" "+custType,
					invoice.getSalesPerson().getLastName()+", "+invoice.getSalesPerson().getFirstName(),
					subtotal,
					fees,
					taxes,
					-discount,
					total);	
			//Increment the grand totals for later
			grandSubtotal += subtotal;
			grandFees += fees;
			grandTaxes += taxes;
			grandDiscount += discount;
			grandTotal += total;
		}
		//Print the grand totals once done
		System.out.println("==================================================================================================================================");
		System.out.printf("%-70s $%10.2f $%10.2f $%10.2f $%10.2f $%10.2f\n","TOTALS",grandSubtotal,grandFees,grandTaxes,grandDiscount,grandTotal);
	}
	//Detailed Report
	public static void PrintDetailReport(InvoiceList invoiceList) {
		System.out.println("Invididual Invoice Detail Reports");
		System.out.println("=================================");
		
		for(int i=0;i<invoiceList.getSize();i++) {
			Invoice invoice = invoiceList.getInvoice(i);
			//Headers
			System.out.println("Invoice "+invoice.getInvoiceCode());
			System.out.println("====================");
			System.out.println("Salesperson: "+invoice.getSalesPerson().getLastName()+", "+invoice.getSalesPerson().getFirstName());
			System.out.println("Customer Info:");
			System.out.println("  "+invoice.getCustomer().getName()+" ("+invoice.getCustomer().getPersonCode()+")");
			if(invoice.getCustomer().getType().equals("S"))
				System.out.println("  [Student]");
			else
				System.out.println("  [General]");
			
			ArrayList<Person> personList = DBReader.readPeople();
			Person person = null;
			for(Person p: personList) {
				if(p.getPersonCode().equals(invoice.getCustomer().getPrimaryContact())) {
					person = p;
					break;
				}
			}
			if(person==null) {
				//if we have bad input data
				System.out.println("  [ERROR BAD INPUT DATA]");
			}
			System.out.println("  "+person.getLastName()+", "+person.getFirstName());
			Address address = invoice.getCustomer().getAddress();
			System.out.println("  "+address.getStreet());
			System.out.println("  "+address.getCity()+" "+address.getState()+" "+address.getZip()+" "+address.getCountry());
			System.out.println("--------------------------------------");
			System.out.printf("%-8s%-80s%12s%12s%12s\n","Code","Item","Subtotal","Tax","Total");
			
			double grandSubTotal = 0;
			double grandTaxes = 0;
			double grandTotal = 0;
			
			//run the printer on each individual purchase
			for(Purchase purchase : invoice.getPurchaseList()) {
				
				//discount string means different things depending on what type of object is being printed
				//but basically it's the bit of flavor text printed after the units sold if they have any special case
				String discountString = "";
				switch(purchase.getProduct().getProductType()){
					case "M":
						MovieTicket movieTicket = (MovieTicket)purchase.getProduct();
						System.out.printf("%-8s%-80s $%10.2f $%10.2f $%10.2f\n",
								purchase.getProduct().getProductCode(),
								"MovieTicket '"+movieTicket.getMovieName()+"' @ "+movieTicket.getAddress().getStreet(),
								purchase.getSubtotal(invoice),
								purchase.getTaxes(invoice),
								purchase.getTotal(invoice));
						//grabbing the day of the week (getDay is depricated and this is what the javadoc pointed to)
						Calendar c = Calendar.getInstance();
						c.setTime(movieTicket.getDateTime());						
						if(c.get(Calendar.DAY_OF_WEEK)==3|c.get(Calendar.DAY_OF_WEEK)==5) 
							discountString = " - Tue/Thu 7% off";
						System.out.println("        "+new SimpleDateFormat("MMM dd,yyyy HH:mm").format(movieTicket.getDateTime())+" ("+purchase.getQuant()+" units @ $"+String.format("%10.2f", movieTicket.getUnitPrice()).trim()+"/unit"+discountString+")");
						break;
					case "S":
						SeasonPass seasonPass = (SeasonPass)purchase.getProduct();
						System.out.printf("%-8s%-80s $%10.2f $%10.2f $%10.2f\n",
								purchase.getProduct().getProductCode(),
								"Season Pass - "+seasonPass.getName(),
								purchase.getSubtotal(invoice),
								purchase.getTaxes(invoice),
								purchase.getTotal(invoice));
						//Comparing the dates of our invoice and season pass to get the prorate
						if(seasonPass.getStartDate().getTime()<invoice.getInvoiceDate().getTime()) {
							int totalDays = (int)TimeUnit.MILLISECONDS.toDays(seasonPass.getEndDate().getTime() - seasonPass.getStartDate().getTime());
							int daysPassed = (int)TimeUnit.MILLISECONDS.toDays(invoice.getInvoiceDate().getTime() - seasonPass.getStartDate().getTime());
							int daysLeft = totalDays-daysPassed;
							discountString = " prorated at "+daysLeft+"/"+totalDays+" days";
						}	
						System.out.println("        ("+purchase.getQuant()+" units @ $"+String.format("%10.2f", seasonPass.getCost()).trim()+"/unit"+discountString+" + $8 fee/unit)");
						break;
					case "P":
						ParkingPass parkingPass = (ParkingPass)purchase.getProduct();
						ParkingPurchase parkingPurchase = (ParkingPurchase)purchase;
						String ticketString = "";
						if(parkingPurchase.getTicketCode()!=null) {
							ticketString = " "+parkingPurchase.getTicketCode();
							//find the number of units we charged on
							int NumUnits = (int)(parkingPurchase.getSubtotal(invoice)/parkingPass.getParkingFee());
							//find how many were free
							int FreeUnits = parkingPurchase.getQuant()-NumUnits;
							discountString = " with "+FreeUnits+" free"; 
						}
						System.out.printf("%-8s%-80s $%10.2f $%10.2f $%10.2f\n",
								purchase.getProduct().getProductCode(),
								"Parking Pass"+ticketString+" ("+purchase.getQuant()+" units @ $"+String.format("%10.2f", parkingPass.getParkingFee()).trim()+"/unit"+discountString+")",
								purchase.getSubtotal(invoice),
								purchase.getTaxes(invoice),
								purchase.getTotal(invoice));
						break;
					case "R":
						Refreshment refreshment = (Refreshment)purchase.getProduct();
						for(Purchase p : invoice.getPurchaseList()) 
							if(p.getPurchaseType().equals("T")) 
								discountString = " with 5% off";
						
						System.out.printf("%-8s%-80s $%10.2f $%10.2f $%10.2f\n",
								purchase.getProduct().getProductCode(),
								refreshment.getName()+" ("+purchase.getQuant()+" units @ $"+String.format("%10.2f", refreshment.getCost()).trim()+"/unit"+discountString+")",
								purchase.getSubtotal(invoice),
								purchase.getTaxes(invoice),
								purchase.getTotal(invoice));
						break;
				}
				grandSubTotal += purchase.getSubtotal(invoice); 
				grandTaxes += purchase.getTaxes(invoice);
				grandTotal += purchase.getTotal(invoice);
			}
			//footer
			System.out.printf("%89s","");
			System.out.println("===================================");
			System.out.printf("%-89s$%10.2f $%10.2f $%10.2f\n",
					"SUB-TOTALS",
					grandSubTotal, 
					grandTaxes,
					grandTotal
			);
			//check if they are a student and print this extra stuff if they had the fees and such
			double discount = 0;
			double fee = 0;
			if(invoice.getCustomer().getType().equals("S")) {
				discount = (grandSubTotal*.08)+grandTaxes;
				System.out.printf("%-113s$%10.2f\n",
						"DISCOUNT ( 8% STUDENT & NO TAX)",
						-discount
				);	
				fee = 6.75;
				System.out.printf("%-113s$%10.2f\n",
						"ADDITIONAL FEE(STUDENT)",
						fee
				);
			}
			System.out.printf("%-113s$%10.2f\n",
					"TOTAL",
					grandTotal-discount+fee
			);		
					
			
			System.out.println("\n\nThank you for your purchase!\n\n");
		}
		System.out.println("==============================================================================================");
	}
}