/*
	Authors: Jonghyun Yoo and Tristan Sladek
	Date: 9/15/2018
	Program: DataWriter
	Description: Will input an objectList, determine the proper
	use of the object, and then output it to the appropriate
	date type (XML or JSON)
*/

package files;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.thoughtworks.xstream.XStream;

public class DataWriter {
	
	//Imports java objects and converts them to XML
	public static void WriteXML(ArrayList<?> objectList) {
		
		//If an object list is sent in, do not use it.
		if(objectList.size()<1) {
			return;
		}
		
		/*
		  Determine the file name of the output. The file name will be the object's class name 
		  IF the object is not a subclass. If the object is a subclass, the filename will be 
		  the Object's superclass.
		*/
		
		String fileName;
		//read as "if the first object in the list does not have the superclass of 'Object'"
		//in which case, the first object is a subclass
		if(!objectList.get(0).getClass().getSuperclass().getSimpleName().equals("Object")) {
			fileName = objectList.get(0).getClass().getSuperclass().getSimpleName();
		}else {
			fileName = objectList.get(0).getClass().getSimpleName();
		}
		fileName+="s";
		
		
		//Initializing our Xstream and StringBuilder objects
		XStream xstream = new XStream(); 
		StringBuilder XML = new StringBuilder();
		//the XML header tag for our output
		XML.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"+"\n"); 
		
		//We read in each object from the list and convert it to XML, then add that string to our stringbuilder
		for(Object o : objectList) {
			//This snippet makes sure that the tag name is shortened to the object's class name
			xstream.alias(o.getClass().getSimpleName(), o.getClass());
			XML.append(xstream.toXML(o));
		}
		
		//All of our XML file is written at once after being processed		
		try {
			FileWriter fr = new FileWriter("data/"+fileName+".xml");
			fr.write(XML.toString());
			fr.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	//Imports java objects and converts them to JSON	
	public static void WriteJSON(ArrayList<?> objectList) {
		//If an object list is sent in, do not use it.
		if(objectList.size()<1) {
			return;
		}
		
		/*
		  Determine the file name of the output. The file name will be the object's class name 
		  IF the object is not a subclass. If the object is a subclass, the filename will be 
		  the Object's superclass.
		*/
		String fileName;
		if(!objectList.get(0).getClass().getSuperclass().getSimpleName().equals("Object")) {
			fileName = objectList.get(0).getClass().getSuperclass().getSimpleName();
		}else {
			fileName = objectList.get(0).getClass().getSimpleName();
		}
		fileName+="s";
		
		//Initializing Gson for converting our ObjectList to JSON
		Gson gson = new GsonBuilder().setPrettyPrinting().create(); 		
		try {
			//With GSON, we can convert and export the entire objectList in one statement
			FileWriter fr = new FileWriter("data/"+fileName+".json");
			fr.write(gson.toJson(objectList));
			fr.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
