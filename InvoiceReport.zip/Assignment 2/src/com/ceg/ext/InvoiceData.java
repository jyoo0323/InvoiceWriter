package com.ceg.ext;

import sql.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


/*
 * This is a collection of utility methods that define a general API for
 * interacting with the database supporting this application.
 * 15 methods in total, add more if required.
 * Do not change any method signatures or the package name.
 * 
 */

public class InvoiceData {

	/**
	 * 1. Method that removes every person record from the database
	 */
	public static void removeAllPersons() {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			conn.createStatement().executeUpdate("delete from PurchaseTicket");
			conn.createStatement().executeUpdate("delete from Purchase");
			conn.createStatement().executeUpdate("delete from Invoice");
			conn.createStatement().executeUpdate("delete from Email");
			conn.createStatement().executeUpdate("delete from Customer");
			conn.createStatement().executeUpdate("delete from Person");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 2. Method to add a person record to the database with the provided data.
	 * 
	 * @param personCode
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param zip
	 * @param country
	 */
	public static void addPerson(String personCode, String firstName, String lastName, String street, String city, String state, String zip, String country)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Person VALUES(?,?,?,?,?,?,?,?)");
			ps.setString(1, personCode);
			ps.setString(2, firstName);
			ps.setString(3, lastName);
			ps.setString(4, street);
			ps.setString(5, city);
			if(state.length()>2) {
				ps.setString(6, state.substring(0,2));	
			}else {
				ps.setString(6, state);
			}			
			ps.setString(7, zip);
			ps.setString(8, country);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 3. Adds an email record corresponding person record corresponding to the
	 * provided <code>personCode</code>
	 * 
	 * @param personCode
	 * @param email
	 */
	public static void addEmail(String personCode, String email)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Email(PersonCode,Email) VALUES(?,?)");
			ps.setString(1, personCode);
			ps.setString(2, email);
			ps.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 4. Method that removes every customer record from the database
	 */
	public static void removeAllCustomers()  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			conn.createStatement().executeUpdate("delete from PurchaseTicket");
			conn.createStatement().executeUpdate("delete from Purchase");
			conn.createStatement().executeUpdate("delete from Invoice");			
			conn.createStatement().executeUpdate("delete from Customer");			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	public static void addCustomer(String customerCode, String customerType, String primaryContactPersonCode,String name, String street, String city, String state, String zip, String country)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Customer VALUES(?,?,?,?,?,?,?,?,?)");
			ps.setString(1, customerCode);
			if(customerType.length()>1) {
				ps.setString(2, customerType.substring(0,1));
			}else {
				ps.setString(2, customerType);
			}
			ps.setString(3, primaryContactPersonCode);
			ps.setString(4, name);
			ps.setString(5, street);
			ps.setString(6, city);
			if(state.length()>2) {
				ps.setString(7, state.substring(0,1));	
			}else {
				ps.setString(7, state);
			}			
			ps.setString(8, zip);
			ps.setString(9, country);
			ps.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}
	
	/**
	 * 5. Removes all product records from the database
	 */
	public static void removeAllProducts()  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			conn.createStatement().executeUpdate("delete from PurchaseTicket");
			conn.createStatement().executeUpdate("delete from MovieTicket");
			conn.createStatement().executeUpdate("delete from ParkingPass");
			conn.createStatement().executeUpdate("delete from Refreshment");
			conn.createStatement().executeUpdate("delete from SeasonPass");
			conn.createStatement().executeUpdate("delete from Purchase");
			conn.createStatement().executeUpdate("delete from Product");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 6. Adds an movieTicket record to the database with the provided data.
	 */
	public static void addMovieTicket(String productCode, String dateTime, String movieName, String street, String city,String state, String zip, String country, String screenNo, double pricePerUnit)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Product VALUES(?,'M')");
			ps.setString(1, productCode);
			ps.executeUpdate();
			
			ps = conn.prepareStatement("INSERT INTO MovieTicket VALUES(?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, productCode);
			ps.setString(2, dateTime);
			ps.setString(3, movieName);
			ps.setString(4, street);
			ps.setString(5, city);
			if(state.length()>2) {
				ps.setString(6, state.substring(0,2));	
			}else {
				ps.setString(6, state);
			}			
			ps.setString(7, zip);
			ps.setString(8, country);
			ps.setString(9, screenNo);
			ps.setDouble(10, pricePerUnit);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 7. Adds a seasonPass record to the database with the provided data.
	 */
	public static void addSeasonPass(String productCode, String name, String seasonStartDate, String seasonEndDate,	double cost)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Product VALUES(?,'S')");
			ps.setString(1, productCode);
			ps.executeUpdate();
			
			ps = conn.prepareStatement("INSERT INTO SeasonPass VALUES(?,?,?,?,?)");
			ps.setString(1, productCode);
			ps.setString(2, name);
			ps.setString(3, seasonStartDate);
			ps.setString(4, seasonEndDate);
			ps.setDouble(5, cost);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 8. Adds a ParkingPass record to the database with the provided data.
	 */
	public static void addParkingPass(String productCode, double parkingFee)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Product VALUES(?,'P')");
			ps.setString(1, productCode);
			ps.executeUpdate();
			
			ps = conn.prepareStatement("INSERT INTO ParkingPass VALUES(?,?)");
			ps.setString(1, productCode);
			ps.setDouble(2, parkingFee);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 9. Adds a refreshment record to the database with the provided data.
	 */
	public static void addRefreshment(String productCode, String name, double cost)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Product VALUES(?,'R')");
			ps.setString(1, productCode);
			ps.executeUpdate();
			
			ps = conn.prepareStatement("INSERT INTO Refreshment VALUES(?,?,?)");
			ps.setString(1, productCode);
			ps.setString(2, name);
			ps.setDouble(3, cost);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 10. Removes all invoice records from the database
	 */
	public static void removeAllInvoices()  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			conn.createStatement().executeUpdate("delete from PurchaseTicket");
			conn.createStatement().executeUpdate("delete from Purchase");
			conn.createStatement().executeUpdate("delete from Invoice");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 11. Adds an invoice record to the database with the given data.
	 */
	public static void addInvoice(String invoiceCode, String customerCode, String salesPersonCode, String invoiceDate) {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Invoice VALUES(?,?,?,?)");
			ps.setString(1, invoiceCode);
			ps.setString(2, customerCode);
			ps.setString(3, salesPersonCode);
			ps.setString(4, invoiceDate);
			ps.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/**
	 * 12. Adds a particular movieticket (corresponding to <code>productCode</code>
	 * to an invoice corresponding to the provided <code>invoiceCode</code> with
	 * the given number of units
	 */

	public static void addMovieTicketToInvoice(String invoiceCode, String productCode, int quantity) {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Purchase(InvoiceCode,ProductCode,Quantity) VALUES(?,?,?)");
			ps.setString(1, invoiceCode);
			ps.setString(2, productCode);
			ps.setInt(3, quantity);
			ps.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

	/*
	 * 13. Adds a particular season pass (corresponding to <code>productCode</code>
	 * to an invoice corresponding to the provided <code>invoiceCode</code> with
	 * the given begin/end dates
	 */
	public static void addSeasonPassToInvoice(String invoiceCode, String productCode, int quantity)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Purchase(InvoiceCode,ProductCode,Quantity) VALUES(?,?,?)");
			ps.setString(1, invoiceCode);
			ps.setString(2, productCode);
			ps.setInt(3, quantity);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

     /**
     * 14. Adds a particular ParkingPass (corresponding to <code>productCode</code> to an 
     * invoice corresponding to the provided <code>invoiceCode</code> with the given
     * number of quantity.
     * NOTE: ticketCode may be null
     */
    public static void addParkingPassToInvoice(String invoiceCode, String productCode, int quantity, String ticketCode)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Purchase(InvoiceCode,ProductCode,Quantity) VALUES(?,?,?)");
			ps.setString(1, invoiceCode);
			ps.setString(2, productCode);
			ps.setInt(3, quantity);
			ps.executeUpdate();		
			if(ticketCode!=null) {
				ps = conn.prepareStatement("INSERT INTO PurchaseTicket VALUES((SELECT PurchaseID FROM Purchase WHERE PurchaseID = @@Identity),?)");
				ps.setString(1, ticketCode);	
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}
	
    /**
     * 15. Adds a particular refreshment (corresponding to <code>productCode</code> to an 
     * invoice corresponding to the provided <code>invoiceCode</code> with the given
     * number of quantity. 
     */
    public static void addRefreshmentToInvoice(String invoiceCode, String productCode, int quantity)  {
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Purchase(InvoiceCode,ProductCode,Quantity) VALUES(?,?,?)");
			ps.setString(1, invoiceCode);
			ps.setString(2, productCode);
			ps.setInt(3, quantity);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
	}

}
