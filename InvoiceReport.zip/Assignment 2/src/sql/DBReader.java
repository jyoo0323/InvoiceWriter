package sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import classes.Address;
import classes.Customer;
import classes.Invoice;
import classes.InvoiceList;
import classes.MoviePurchase;
import classes.MovieTicket;
import classes.ParkingPass;
import classes.ParkingPurchase;
import classes.Person;
import classes.Product;
import classes.Purchase;
import classes.Refreshment;
import classes.RefreshmentPurchase;
import classes.SeasonPass;
import classes.SeasonPassPurchase;

public class DBReader {
	//Reads in the customers from the database and outputs an arraylist of Java Objects
	public static ArrayList<Customer> readCustomers(){
		//Initializing our list
		ArrayList<Customer> customers = new ArrayList<Customer>();		
		
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			ResultSet rs = conn.createStatement().executeQuery("select * from Customer");	
			while(rs.next()) {
				customers.add(new Customer(
				rs.getString("CustomerCode"),
				rs.getString("CustomerType"),
				rs.getString("CustomerContact"),
				rs.getString("CustomerName"),
				new Address(rs.getString("Street"),rs.getString("City"),rs.getString("State"),rs.getString("Zip"),rs.getString("Country"))
				)); //Create the customer
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection
		
		
		//return the arrayList when all processing is done
		return customers;
	}
	
	public static ArrayList<Person> readPeople(){
		//Initializing our list
		ArrayList<Person> people = new ArrayList<Person>();
		
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			ResultSet rs = conn.createStatement().executeQuery("select * from Person");	
			while(rs.next()) {
				
				ArrayList<String> emailList = new ArrayList<String>(); //grab all emails for this person
				ResultSet rs2 = conn.createStatement().executeQuery("select Email from Email where PersonCode = '"+rs.getString("PersonCode")+"'");
				while(rs2.next()) {
					emailList.add(rs2.getString("Email"));
				}
				rs2.close();
				
				
				people.add(new Person(
				rs.getString("PersonCode"),
				rs.getString("LastName"),
				rs.getString("FirstName"),
				new Address(rs.getString("Street"),rs.getString("City"),rs.getString("State"),rs.getString("Zip"),rs.getString("Country")),
				emailList
				)); //Create the person
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection		
		
		//return the arrayList when all processing is done
		return people;
	}
	
	public static ArrayList<Product> readProducts(){
		//Initializing our list
		ArrayList<Product> products = new ArrayList<Product>();
		
		Connection conn = DBUtil.GetConnection(); //open connection
		try {
			ResultSet rs = conn.createStatement().executeQuery("select * from MovieTicket");	
			while(rs.next()) {
				products.add(new MovieTicket(
					rs.getString("ProductCode"),
					"M",
					new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(rs.getString("MovieDate")),						
					rs.getString("MovieName"),
					new Address(rs.getString("Street"),rs.getString("City"),rs.getString("State"),rs.getString("Zip"),rs.getString("Country")),
					rs.getString("ScreenNo"),
					rs.getDouble("UnitPrice")
				)); //create the movie ticket
			}
			rs.close();
			rs = conn.createStatement().executeQuery("select * from ParkingPass");	
			while(rs.next()) {
				products.add(new ParkingPass(
					rs.getString("ProductCode"),
					"P",
					rs.getDouble("ParkingFee")
				)); //create the parking pass
			}
			rs.close();
			rs = conn.createStatement().executeQuery("select * from Refreshment");	
			while(rs.next()) {
				products.add(new Refreshment(
					rs.getString("ProductCode"),
					"R",
					rs.getString("RefreshmentName"),
					rs.getDouble("RefreshmentCost")
				)); //create the refreshment
			}
			rs.close();
			rs = conn.createStatement().executeQuery("select * from SeasonPass");	
			while(rs.next()) {
				products.add(new SeasonPass(
					rs.getString("ProductCode"),
					"S",
					rs.getString("SeasonPassName"),
					new SimpleDateFormat("yyyy-MM-dd").parse(rs.getString("StartDate")),
					new SimpleDateFormat("yyyy-MM-dd").parse(rs.getString("EndDate")),
					rs.getDouble("SeasonPassCost")
				)); //create the season pass
			}
			rs.close();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtil.closeConnection(conn); //close connection		
		
		//returning our product list once all processing is done
		return products;
	}
	public static InvoiceList readInvoices(){
		//Initializing our list
		InvoiceList invoices = new InvoiceList();
		ArrayList<Customer> customers = DBReader.readCustomers();
		ArrayList<Product> products = DBReader.readProducts();
		ArrayList<Person> people = DBReader.readPeople();
		
		Connection conn = DBUtil.GetConnection(); //open connection		
		
		
		try {	
			ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM PurchaseTicket");
			Map<Integer,String> purchaseTicket = new HashMap<Integer,String>(); //hashmap of purchase tickets
			while(rs.next()) {
				purchaseTicket.put(rs.getInt("PurchaseID"), rs.getString("TicketCode"));
			}
			
			rs = conn.createStatement().executeQuery("SELECT * FROM Purchase join Invoice where Invoice.invoiceCode = Purchase.InvoiceCode order by Invoice.InvoiceCode");
			ArrayList<Purchase> purchaseList = new ArrayList<Purchase>();
			
			//Creating these for later use
			String curInvoice=null;
			Date invoiceDate = null;
			Customer customer = null;
			Person person = null;
			
			while(rs.next()) {
				if(curInvoice==null) {
					curInvoice=rs.getString("Invoice.InvoiceCode");
					invoiceDate = new SimpleDateFormat("yyyy-MM-dd").parse(rs.getString("InvoiceDate"));
					for(Customer c : customers) {
						if(c.getPersonCode().equals(rs.getString("CustomerCode"))) {
							customer = c;
							break;
						}
					}
					for(Person p: people) {
						if(p.getPersonCode().equals(rs.getString("PersonCode"))) {
							person = p;
							break;
						}
					} 
				} //set the invoice to the current invoice
				if(!curInvoice.equals(rs.getString("Invoice.InvoiceCode"))) {//if we're no longer on our current invoice
					invoices.add(new Invoice(
					curInvoice,
					customer,
					person,
					invoiceDate,
					purchaseList
					));	//create our invoice for the last invoice
					//setup our new invoice
					curInvoice=rs.getString("Invoice.InvoiceCode");
					invoiceDate = new SimpleDateFormat("yyyy-MM-dd").parse(rs.getString("InvoiceDate"));
					for(Customer c : customers) {
						if(c.getPersonCode().equals(rs.getString("CustomerCode"))) {
							customer = c;
							break;
						}
					}
					for(Person p: people) {
						if(p.getPersonCode().equals(rs.getString("PersonCode"))) {
							person = p;
							break;
						}
					}	
					
					//reset the purchase list
					purchaseList = new ArrayList<Purchase>();
				}
				Product theProduct = null; //find the product we're working with					
				for(Product p:products) {
					if(p.getProductCode().equals(rs.getString("ProductCode"))){
						theProduct = p;
						break;
					}
				}					
				switch(theProduct.getProductType()) {
				case "M":
					purchaseList.add(new MoviePurchase(rs.getInt("Quantity"),theProduct));
					break;
				case "S":
					purchaseList.add(new SeasonPassPurchase(rs.getInt("Quantity"),theProduct));
					break;
				case "P":
					if(purchaseTicket.containsKey(rs.getInt("PurchaseID"))) { //if our hashmap has a ticket tied to this purchase, add it to the purchase
						purchaseList.add(new ParkingPurchase(rs.getInt("Quantity"),theProduct,purchaseTicket.get(rs.getInt("PurchaseID"))));
					}else {
						purchaseList.add(new ParkingPurchase(rs.getInt("Quantity"),theProduct));
					}						
					break;
				case "R":
					purchaseList.add(new RefreshmentPurchase(rs.getInt("Quantity"),theProduct));
					break;
				}
			}
			rs.close();
			
			if(curInvoice != null) {
				invoices.add(new Invoice(
					curInvoice,
					customer,
					person,
					invoiceDate,
					purchaseList
				));	//create the last invoice
			}
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//returning our product list once all processing is done
		return invoices;
	}
}
