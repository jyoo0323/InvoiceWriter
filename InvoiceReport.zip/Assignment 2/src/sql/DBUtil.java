package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBUtil {
	//JDBC Driver and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://cse.unl.edu:3306/jyoo";
	
	//Database credentials
    static final String USER = "jyoo";
    static final String PASS = "Z4dIZ9";
    
    public static Connection GetConnection() {
    	//create connection 
    	try {
    		Class.forName(JDBC_DRIVER); //find the driver class
    		Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //create connection to database
    		return conn; //return connection
    	} catch (SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			System.err.println(e);
			System.exit (-1);
		}
    	return null;
    }
    
    public static void closeConnection(Connection conn) {
    	try {
    		conn.close();
    	} catch (SQLException e) {
			e.printStackTrace();
		}
    }
}
