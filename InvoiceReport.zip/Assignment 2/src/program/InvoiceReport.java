package program;

import classes.InvoiceList;
import files.ReportWriter;
import sql.DBReader;

public class InvoiceReport {
	public static void main(String args[]) {		
		InvoiceList il = DBReader.readInvoices();
		DBReader.readInvoices();
		
		ReportWriter.PrintSummaryReport(il);
		System.out.println("\n\n\n\n\n"); //Extra white space
		ReportWriter.PrintDetailReport(il);
	}
}
