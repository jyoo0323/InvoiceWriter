/*
	Authors: Jonghyun Yoo and Tristan Sladek
	Date: 9/15/2018
	Program: Data Converter
	Description: Will input .dat files, convert them into arrayLists of 
	objects, and then use the object list to output .JSON and .XML files
*/

package program;

import java.util.ArrayList;

import classes.Customer;
import classes.Person;
import classes.Product;
import files.DataReader;
import files.DataWriter;

public class DataConverter {
	public static void main(String[] args) {
		
		//Customers.dat is read in from the file, and exported to XML and JSON
		ArrayList<Customer> customers = DataReader.readCustomers();
		DataWriter.WriteXML(customers);
		DataWriter.WriteJSON(customers);
		
		//Persons.dat is read in from the file, and exported to XML and JSON
		ArrayList<Person> people = DataReader.readPeople();
		DataWriter.WriteXML(people);
		DataWriter.WriteJSON(people);

		//Products.dat is read in from the file, and exported to XML and JSON
		ArrayList<Product> products = DataReader.readProducts();
		DataWriter.WriteXML(products);
		DataWriter.WriteJSON(products);
	}
}
