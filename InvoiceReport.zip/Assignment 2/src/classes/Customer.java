package classes;

public class Customer {
	private String personCode,type,primaryContact,name;
	private Address address;
	
	//constructor takes in an array of elements and generates itself
	public Customer(String[]args) {
		this.personCode=args[0];
		this.type=args[1];
		this.primaryContact=args[2];
		this.name=args[3];
		//creates an address object using these following string arguments
		this.address = new Address(args[4],args[5],args[6],args[7],args[8]);
	}	
	public Customer(String personCode, String type, String primaryContact, String name, Address address ) {
		this.personCode = personCode;
		this.type = type;
		this.primaryContact = primaryContact;
		this.name = name;
		this.address = address;
	}
	
	//getters and setters
	public String getPersonCode() {
		return personCode;
	}
	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPrimaryContact() {
		return primaryContact;
	}
	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
}
