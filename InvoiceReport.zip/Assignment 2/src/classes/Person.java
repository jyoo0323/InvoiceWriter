package classes;

import java.util.ArrayList;

public class Person {
	private String personCode,firstName,lastName;
	private Address address;
	private ArrayList<String> email;
	
	//this constructor takes in a string array of args and splits them into a java object
	public Person(String[] args) {
		this.personCode=args[0];
		this.lastName=args[1].trim();
		this.firstName=args[2].trim();
		//creates an address object using these following string arguments
		this.address=new Address(args[3],args[4],args[5],args[6],args[7]);
		this.email = new ArrayList<String>();
		//if it has zero emails, it won't add any to the list. 
		//if there are emails, they will be every argument after 8
		for(int i=0;i<args.length-8;i++) {
			this.email.add(args[i+8]);
		}
	}
	//this constructor takes in every variable as input and creates an object
	public Person(String personCode,String lastName,String firstName,Address address, ArrayList<String> email) {
		this.personCode = personCode;
		this.firstName = firstName.trim();
		this.lastName = lastName.trim();
		this.address = address;
		this.email = email;
	}
	
	//method for adding in a single email(so you don't wipe the list)
	public void addEmail(String email) {
		this.email.add(email);
	}
	
	//Getters and Setters 
	
	public String getPersonCode() {
		return personCode;
	}

	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public ArrayList<String> getEmail() {
		return email;
	}

	public void setEmail(ArrayList<String> email) {
		this.email = email;
	}
	
}
