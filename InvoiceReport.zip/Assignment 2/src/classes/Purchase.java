package classes;

public abstract class Purchase {
	int quant;
	Product product;
	
	//Constructor
	public Purchase(int quant, Product product) {
		this.quant = quant;
		this.product = product;
	}
	
	//utility method for adding to the quantity
	public void addQuant(int amount) {
		this.quant += amount;
	}

	//Abstract Methods
	public abstract double getSubtotal(Invoice invoice);
	public abstract double getTaxes(Invoice invoice);
	public abstract double getTotal(Invoice invoice);
	public abstract String getPurchaseType();
	
	//Getters and Setters
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
}
