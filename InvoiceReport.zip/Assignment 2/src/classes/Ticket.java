package classes;

//this is one of the types of Purchase the customer will make.
public abstract class Ticket extends Purchase{
	public Ticket(int quant, Product product) {
		super(quant, product);
	}
	@Override
	public double getTaxes(Invoice invoice) {
		return this.getSubtotal(invoice)*.06;
	}
	@Override
	public String getPurchaseType() {
		return "T";
	}
	@Override
	public double getTotal(Invoice invoice) {
		return this.getTaxes(invoice)+this.getSubtotal(invoice);
	}
}
