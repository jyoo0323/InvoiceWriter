package classes;

public class RefreshmentPurchase extends Service{

	//Constructor, calling super constructor
	public RefreshmentPurchase(int quant, Product product) {
		super(quant, product);
	}
	//Abstracts, it's really simple
	@Override
	public double getSubtotal(Invoice invoice) {
		Refreshment refreshment = (Refreshment)this.getProduct();
		//check for discount
		for(Purchase purchase : invoice.getPurchaseList()) {
			if(purchase.getPurchaseType().equals("T")) {
				return (this.getQuant()*refreshment.getCost())*.95; 
			}
		}
		return this.getQuant()*refreshment.getCost();
	}
}
