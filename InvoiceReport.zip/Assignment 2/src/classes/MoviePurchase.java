package classes;
import java.util.Calendar;

import classes.MovieTicket;

public class MoviePurchase extends Ticket{
	
	//Constructor, calling super constructor
	public MoviePurchase(int quant, Product product) {
		super(quant, product);
	}
	@Override
	public double getSubtotal(Invoice invoice) {
		//Cast our movie ticket object
		MovieTicket ticket = (MovieTicket)this.getProduct();
		//grabbing the day of the week (getDay is depricated and this is what the javadoc pointed to)
		
		//Set a calendar to the date on our ticket
		Calendar c = Calendar.getInstance();
		c.setTime(ticket.getDateTime());
		
		//Check if it is Tuesday or Thursday
		if(c.get(Calendar.DAY_OF_WEEK)==3|c.get(Calendar.DAY_OF_WEEK)==5) {
			return ticket.getUnitPrice()*this.quant*.93;
		}
		return ticket.getUnitPrice()*this.quant;
	}
}
