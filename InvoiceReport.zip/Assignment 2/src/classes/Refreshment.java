package classes;

public class Refreshment extends Product {
	private String name;
	private double cost;
	
	//this constructor takes in a string array of args and splits them into a java object
	public Refreshment(String[]args) {
		this.setProductCode(args[0]);
		this.setProductType(args[1]);
		this.name=args[2];
		this.cost=Double.parseDouble(args[3]);
	}
	//this constructor takes in every variable as input and creates an object
	public Refreshment(String productCode,String productType, String name, double cost) {
		this.setProductCode(productCode);
		this.setProductType(productType);
		this.name = name;
		this.cost = cost;
	}
	//getters and setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}	
}
