package classes;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MovieTicket extends Product{
	private String movieName, screenNo;
	private Date dateTime;
	private Address address;
	private double unitPrice;
	
	//this constructor takes in a string array of args and splits them into a java object
	public MovieTicket(String[] args) {
		this.setProductCode(args[0]);
		this.setProductType(args[1]);
		//parses a date from the string argument, "year-month-day hour:minute"
		try {
			this.dateTime=new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(args[2]);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.movieName=args[3];
		//creates an address object using these following string arguments
		this.address=new Address(args[4],args[5],args[6],args[7],args[8]);
		this.screenNo=args[9];
		this.unitPrice=Double.parseDouble(args[10]);
	}
	//this constructor takes in every variable as input and creates an object
	public MovieTicket(String productCode,String productType, Date dateTime,String movieName, Address address, String screenNo, double unitPrice) {
		this.setProductCode(productCode);
		this.setProductType(productType);
		this.movieName = movieName;
		this.screenNo = screenNo;
		this.dateTime = dateTime;
		this.address = address;
		this.unitPrice = unitPrice;
	}
	//getters and setters
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getScreenNo() {
		return screenNo;
	}
	public void setScreenNo(String screenNo) {
		this.screenNo = screenNo;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
}
