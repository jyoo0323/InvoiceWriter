package classes;

public class InvoiceList {
	private InvoiceNode start;
	private InvoiceNode end;
	private int size;
	
	public InvoiceList() {
		//call clear, which resets all values to zero/null
		this.clear();
	}
	
	public boolean isEmpty() {
		return this.start == null;
	}
	
	public int getSize() {
		return this.size;
	}
	
	public void clear() {
		//resets all values to zero/null
		this.start = null;
		this.end = null;
		this.size = 0;
	}
	
	public void add(Invoice invoice) {
		InvoiceNode newNode = new InvoiceNode(invoice);
		if(this.start == null) { //empty list
			this.start = newNode;
			this.end = this.start;
		}else {			
			double findTotal = 0; //total price of the invoice we're comparing
			for(Purchase purchase : invoice.getPurchaseList()) {
				findTotal += purchase.getTotal(invoice);
			}
			double compareTotal = 0;//the total of the first node in our table
			for(Purchase purchase : this.start.getInvoice().getPurchaseList()) { 
				compareTotal += purchase.getTotal(this.start.getInvoice());
			}
			if(findTotal>compareTotal) { //add to start
				newNode.setNext(this.start);
				this.start = newNode;	
			}else{
				compareTotal = 0;//the total of the last node in our table
				for(Purchase purchase : this.end.getInvoice().getPurchaseList()) { 
					compareTotal += purchase.getTotal(this.end.getInvoice());
				}
				if(findTotal<compareTotal) { //add to end
					this.end.setNext(newNode);
					this.end = newNode;	
				}else { //check the middle if not > start or < end
					InvoiceNode currentNode = this.start; //node we're tracking
					InvoiceNode lastNode = null; //last node we used
					for(int i=1;i<size;i++) {
						lastNode = currentNode;
						currentNode=currentNode.getNext();
						compareTotal = 0;//total of node we're comparing
						for(Purchase purchase : currentNode.getInvoice().getPurchaseList()) { 
							compareTotal += purchase.getTotal(currentNode.getInvoice());
						}
						if(findTotal>compareTotal) { //if our total is finally higher than this next node
							//insert our node between current node and last node
							newNode.setNext(currentNode);
							lastNode.setNext(newNode);
							break; //stop when you hit the last
						}
					}
				}	
			}	
		}
		this.size++;
	}
	
	public void remove(int pos) {
		if(pos+1>size) throw new IndexOutOfBoundsException("Index out of bounds!"); //index of list starts from zero
		InvoiceNode node = this.start; 
		if(pos==0) { //first node
			this.start = node.getNext();
		}else if(pos+1==this.size) { //last node
			for(int i=1;i<pos;i++) {
				node = node.getNext();
			}
			node.setNext(null);
			this.end = node;
		}else{//middle node
			for(int i=1;i<pos;i++) {
				node=node.getNext();
			}
			InvoiceNode lastNode = node;
			node=node.getNext();
			lastNode.setNext(node.getNext()); //last node next value set to current node's next value
		}
		this.size--;		
	}
	
	public InvoiceNode getInvoiceNode(int pos) {
		if(pos+1>size) throw new IndexOutOfBoundsException("Index out of bounds!"); //index of list starts from zero
		InvoiceNode node = this.start;
		for(int i=1;i<=pos;i++) {
			node=node.getNext();			
		}		
		return node;
	}
	
	public Invoice getInvoice(int pos) {
		if(pos+1>size) throw new IndexOutOfBoundsException("Index out of bounds!"); //index of list starts from zero
		InvoiceNode node = this.start;
		for(int i=1;i<=pos;i++) {
			node=node.getNext();			
		}		
		return node.getInvoice();
	}	
}
