package classes;

public class ParkingPurchase extends Service{
	String ticketCode;
	
	
	//Constructor, calling super constructor without ticket code
		public ParkingPurchase(int quant, Product product) {
			super(quant, product);
			this.ticketCode = null;
		}
	//Constructor, calling super constructor with ticket code
	public ParkingPurchase(int quant, Product product,String ticketCode) {
		super(quant, product);
		this.ticketCode = ticketCode;
	}
	//Getters and Setters
	public String getTicketCode() {
		return ticketCode;
	}
	public void setTicketCode(String ticketCode) {
		this.ticketCode = ticketCode;
	}
	
	//Abstract Methods
	@Override
	public double getSubtotal(Invoice invoice) {
		ParkingPass parkingPass = (ParkingPass) this.getProduct();
		//We're checking if this parking pass has a ticket code that is actually included in this invoice purchase,
		//then discounting for however many tickets this purchase had linked to this pass.
		for(Purchase purchase : invoice.getPurchaseList()) {
			if(purchase.getPurchaseType().equals("T")) {
				if(purchase.getProduct().getProductCode().equals(this.getTicketCode())) {
					if(purchase.getQuant() > this.getQuant()) {
						return 0;
					}else {
						return parkingPass.getParkingFee() * (this.getQuant()-purchase.getQuant());
					}						
				}
			}
		}		
		return parkingPass.getParkingFee() * this.getQuant();
	}	
}
