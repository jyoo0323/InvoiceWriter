package classes;

public abstract class Product {
	private String productCode,productType;
	
	//This is the abstract superclass for all products, below are getters and setters for variables that all products need
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}	
}
