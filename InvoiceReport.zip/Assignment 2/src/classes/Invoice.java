package classes;
import java.util.ArrayList;
import java.util.Date;

public class Invoice {
	String invoiceCode;
	Customer customer;
	Person salesPerson;
	Date invoiceDate;
	ArrayList<Purchase> purchaseList;
	
	//Constructor
	public Invoice(String invoiceCode, Customer customer, Person salesPerson, Date invoiceDate, ArrayList<Purchase> purchaseList) {
		this.invoiceCode = invoiceCode;
		this.customer = customer;
		this.salesPerson = salesPerson;
		this.invoiceDate = invoiceDate;
		this.purchaseList = purchaseList;
	}
	//Blank Constructor
	public Invoice() {
		//instantiating this variable to prevent errors in the future
		this.purchaseList = new ArrayList<Purchase>();
	}
	
	//Method for adding a purchase to the list
	public void AddPurchase(Purchase purchase) {
		this.purchaseList.add(purchase);
	}	
	
	//Getters and Setters
	public String getInvoiceCode() {
		return invoiceCode;
	}
	public void setInvoiceCode(String invoiceCode) {
		this.invoiceCode = invoiceCode;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Person getSalesPerson() {
		return salesPerson;
	}
	public void setSalesPerson(Person salesPerson) {
		this.salesPerson = salesPerson;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public ArrayList<Purchase> getPurchaseList() {
		return purchaseList;
	}
	public void setPurchaseList(ArrayList<Purchase> purchaseList) {
		this.purchaseList = purchaseList;
	}	
}
