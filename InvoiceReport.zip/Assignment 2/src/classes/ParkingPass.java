package classes;

public class ParkingPass extends Product{
	private double parkingFee;
	//this constructor takes in a string array of args and splits them into a java object
	public ParkingPass(String[] args) {
		this.setProductCode(args[0]);
		this.setProductType(args[1]);
		this.parkingFee = Double.parseDouble(args[2]);
	}
	//this constructor takes in every variable as input and creates an object
	public ParkingPass(String productCode,String productType,double parkingFee) {
		this.setProductCode(productCode);
		this.setProductType(productType);
		this.parkingFee = parkingFee;
	}
	//getters and setters
	public double getParkingFee() {
		return parkingFee;
	}
	public void setParkingFee(double parakingFee) {
		this.parkingFee = parakingFee;
	}	
}
