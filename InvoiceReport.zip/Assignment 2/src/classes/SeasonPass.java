package classes;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SeasonPass extends Product {
	private String name;
	private Date startDate, endDate;
	private double cost;
	
	//This constructor takes in a string array of args and splits them out into an object
	public SeasonPass(String[] args) {
		this.setProductCode(args[0]);
		this.setProductType(args[1]);
		this.name = args[2];
		//converts a date from strings to the date format below
		try {
			this.startDate=new SimpleDateFormat("yyyy-MM-dd").parse(args[3]);
			this.endDate=new SimpleDateFormat("yyyy-MM-dd").parse(args[4]);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.cost=Double.parseDouble(args[5]);
	}
	
	//this constructor takes in all variables as input and creates an object
	public SeasonPass(String productCode,String productType,String name, Date startDate,Date endDate,double cost) {
		this.setProductCode(productCode);
		this.setProductType(productType);
		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.cost = cost;
	}
	
	//getters and setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}	
}
