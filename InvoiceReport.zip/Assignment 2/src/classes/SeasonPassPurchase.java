package classes;

import java.util.concurrent.TimeUnit;

public class SeasonPassPurchase extends Ticket{

	//Constructor, calling super constructor
	public SeasonPassPurchase(int quant, Product product) {
		super(quant, product);
	}
	@Override
	public double getSubtotal(Invoice invoice) {
		SeasonPass seasonPass = (SeasonPass)this.getProduct();		
		//if the invoice date came after the start date, use prorate
		if(seasonPass.getStartDate().getTime()<invoice.getInvoiceDate().getTime()) {
			//Prorate
			int totalDays = (int)TimeUnit.MILLISECONDS.toDays(seasonPass.getEndDate().getTime() - seasonPass.getStartDate().getTime());
			int daysPassed = (int)TimeUnit.MILLISECONDS.toDays(invoice.getInvoiceDate().getTime() - seasonPass.getStartDate().getTime());
			double daysLeft = totalDays-daysPassed;
			double prorate = (daysLeft/totalDays);
			return this.getQuant()*((seasonPass.getCost()*prorate)+8);
		}else {
			//No Prorate
			return this.getQuant()*(seasonPass.getCost()+8);
		}		
	}
}
