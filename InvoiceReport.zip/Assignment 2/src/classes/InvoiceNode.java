package classes;

public class InvoiceNode {
	private InvoiceNode next;
	private Invoice item;
	
	public InvoiceNode(Invoice item) {
		this.item = item;
		this.next = null;
	}
	
	public Invoice getInvoice() {
		return this.item;
	}
	
	public InvoiceNode getNext() {
		return this.next;
	}
	
	public void setNext(InvoiceNode next) {
		this.next = next;
	}
}
